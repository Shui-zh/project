#!/usr/bin/env bash

set -e
cd "$(dirname "$0")"

source /opt/ros/humble/setup.bash
colcon build
source install/setup.bash

ros2 launch min_snap_planner_demo run_all.launch.py