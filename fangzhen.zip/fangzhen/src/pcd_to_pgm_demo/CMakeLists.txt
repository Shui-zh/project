cmake_minimum_required(VERSION 3.8)
project(pcd_to_pgm_demo CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()
add_compile_options(-O2 -Wall -Wextra)

# find dependencies
find_package(ament_cmake REQUIRED)
find_package(rclcpp REQUIRED)
find_package(sensor_msgs REQUIRED)
find_package(nav_msgs REQUIRED)
find_package(pcl_conversions REQUIRED)
find_package(ament_index_cpp REQUIRED)
find_package(PCL REQUIRED COMPONENTS common io filters)

add_executable(pcd_to_pgm_node src/pcd_to_pgm.cpp)
ament_target_dependencies(
  pcd_to_pgm_node
  "rclcpp"
  "sensor_msgs"
  "nav_msgs"
  "pcl_conversions"
  "ament_index_cpp"
)
target_include_directories(pcd_to_pgm_node SYSTEM PRIVATE ${PCL_INCLUDE_DIRS})
target_link_directories(pcd_to_pgm_node PRIVATE ${PCL_LIBRARY_DIRS})
target_link_libraries(pcd_to_pgm_node ${PCL_LIBRARIES})

install(TARGETS pcd_to_pgm_node DESTINATION lib/${PROJECT_NAME})
install(DIRECTORY launch config DESTINATION share/${PROJECT_NAME})
install(FILES data/rmul_2025.pcd DESTINATION share/${PROJECT_NAME}/data)

ament_package()
