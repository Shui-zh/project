cmake_minimum_required(VERSION 3.8)
project(min_snap_planner_demo CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()
add_compile_options(-O2 -Wall -Wextra)


# find dependencies
find_package(ament_cmake REQUIRED)
find_package(rclcpp REQUIRED)
find_package(geometry_msgs REQUIRED)
find_package(nav_msgs REQUIRED)
find_package(trajectory_msgs REQUIRED)
find_package(eigen3_cmake_module REQUIRED)
find_package(Eigen3 REQUIRED)

add_executable(min_snap_planner_node src/min_snap_planner.cpp)
ament_target_dependencies(
  min_snap_planner_node
  "rclcpp"
  "geometry_msgs"
  "nav_msgs"
  "trajectory_msgs"
)
target_link_libraries(min_snap_planner_node Eigen3::Eigen)

install(TARGETS min_snap_planner_node DESTINATION lib/${PROJECT_NAME})
install(DIRECTORY config launch DESTINATION share/${PROJECT_NAME})

ament_package()
