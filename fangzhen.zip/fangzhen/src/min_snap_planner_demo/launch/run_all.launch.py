import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node


def include_pkg_launch(package, filename):
    """把某个包 launch/ 下的文件包含进来（走 install 后的 share 目录）。"""
    path = os.path.join(get_package_share_directory(package), 'launch', filename)
    return IncludeLaunchDescription(PythonLaunchDescriptionSource(path))


def generate_launch_description() -> LaunchDescription:

    pcd_to_pgm = include_pkg_launch('pcd_to_pgm_demo', 'pcd_to_pgm.launch.py')
    astar_planner = include_pkg_launch('astar_planner_demo', 'astar_planner.launch.py')
    min_snap = include_pkg_launch('min_snap_planner_demo', 'min_snap_planner.launch.py')
        

    return LaunchDescription([
        pcd_to_pgm,
        astar_planner,
        min_snap,
    ])
