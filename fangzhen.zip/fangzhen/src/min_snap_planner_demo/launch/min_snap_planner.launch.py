import os

from launch_ros.actions import Node
from launch import LaunchDescription
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    params_file = os.path.join(get_package_share_directory("min_snap_planner_demo"), "config", "params.yaml")
    return LaunchDescription([
        Node(
            package="min_snap_planner_demo",
            executable="min_snap_planner_node",
            name="min_snap",
            output="screen",
            parameters=[params_file],
        ),
    ])